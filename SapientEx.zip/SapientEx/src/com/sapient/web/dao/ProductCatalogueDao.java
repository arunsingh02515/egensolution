package com.sapient.web.dao;

import java.util.List;

import com.sapient.web.domain.Product;
import com.sapient.web.model.ProductVo;

public interface ProductCatalogueDao {
	public void addProduct(Product product);
	public List<?> getAllProduct();
	public void removeProduct(int productId);
	public List<?> getProduct(String productName);
}
