package com.sapient.web.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sapient.web.dao.ProductCatalogueDao;
import com.sapient.web.domain.Product;
import com.sapient.web.model.ProductVo;
@Repository
public class ProductCatalogueDaoImpl implements ProductCatalogueDao {
	@Autowired
    private SessionFactory sessionFactory;
	
	public void addProduct(Product product){
		this.sessionFactory.getCurrentSession().save(product);
	}
	public List<?> getProduct(String productName){
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Product.class,"product");
		//crit.createAlias("product.stock", "stock1");
		crit.add(Restrictions.eq("name", productName));
		List<?> result=crit.list();
		return result;
	}
	public List<?> getAllProduct(){
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Product.class,"product");
		crit.createAlias("product.stock", "stock1");
		//crit.setResultTransformer(Criteria.);
		List<?> result=crit.list();
		return result;
		
	}
	public void removeProduct(int productId){
		Product product=(Product)this.sessionFactory.getCurrentSession().load(Product.class, productId);
		
        if (null != product) 
        	this.sessionFactory.getCurrentSession().delete(product);
		
		
	}
	/*public  List<?> getProductByProductType(String productType){
		Criteria crit = this.sessionFactory.getCurrentSession().createCriteria(Product.class,"product");
		crit.createAlias("product.stock", "stock1");
		crit.add(Restrictions.eq("stock1.productType", productType));
		List<?> result=crit.list();
		return result;
	}*/
}
