package com.sapient.web.constant;

public class SapientConstants {
 public static final String PRODUCTCATELOGADDSERVICE="productcatelog/add";
 public static final String PRODUCTCATELOGLISTSERVICE="productcatelog/productlist";
 public static final String PRODUCTCATELOGREMOVESERVICE="productcatelog/remove/{productId}";
 public static final String PRODUCTCATELOGBYPRODUCTNAME="productcatelog/{productname}";
 public static final String PRICESERVICE="priceservice/{productname}";
 
}
