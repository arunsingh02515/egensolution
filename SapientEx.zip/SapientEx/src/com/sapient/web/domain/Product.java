package com.sapient.web.domain;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.GenericGenerator;

@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)

@Entity(name="Product")
@Table(name="Product")
public class Product implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	 @GenericGenerator(name="kaugen" , strategy="increment")
	 @GeneratedValue(generator="kaugen")
	@Column(name="productid")
	private int id;
	
	@Column(name="productname")
	private String name;
	@Column(name="productdesc")
	private String desc;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="productid")
	private Stock stock;
	
	public Stock getStock() {
		return stock;
	}
	public void setStock(Stock stock) {
		this.stock = stock;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
}
