package com.sapient.web.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.GenericGenerator;

@Cache(usage=CacheConcurrencyStrategy.READ_WRITE)

@Entity(name="Stock")
@Table(name="Stock")
public class Stock implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	 @GenericGenerator(name="kaugen" , strategy="increment")
	 @GeneratedValue(generator="kaugen")
	@Column(name="productid")
	private int id;
	@Column(name="price")
	private int price;
	@Column(name="unit")
	private int unit;
	@Column(name="producttype")
	private String productType;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getUnit() {
		return unit;
	}
	public void setUnit(int unit) {
		this.unit = unit;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	
	
	
	
}
