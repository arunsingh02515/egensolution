package com.sapient.web.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sapient.web.model.ProductVo;
import com.sapient.web.util.ProductNotFoundException;

public interface ProductCatalogueService {
	public void addProduct(ProductVo product);
	public List<ProductVo> getAllProduct();
	public void removeProduct(int productId);
	public ProductVo getProduct(String productName) throws ProductNotFoundException;
}
