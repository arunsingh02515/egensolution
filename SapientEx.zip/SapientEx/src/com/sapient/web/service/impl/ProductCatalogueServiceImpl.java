package com.sapient.web.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sapient.web.dao.ProductCatalogueDao;
import com.sapient.web.domain.Product;
import com.sapient.web.domain.Stock;
import com.sapient.web.model.ProductVo;
import com.sapient.web.service.ProductCatalogueService;
import com.sapient.web.util.ProductNotFoundException;
@Service
@Transactional
public class ProductCatalogueServiceImpl implements ProductCatalogueService{
	
	@Autowired
	ProductCatalogueDao productCatalogueDao;
	public void addProduct(ProductVo productVo){
		Product product= new Product();
		product.setName(productVo.getName());
		product.setDesc(productVo.getDesc());
		Stock stock=new Stock();
		stock.setPrice(productVo.getPrice());
		stock.setUnit(productVo.getUnit());
		stock.setProductType(productVo.getProductType());
		product.setStock(stock);
		productCatalogueDao.addProduct(product);
	}
	public ProductVo getProduct(String productName) throws ProductNotFoundException{
		ProductVo productVo= new ProductVo();
		List<?> list=productCatalogueDao.getProduct(productName);
		if(list.size()==0){
			
				throw new ProductNotFoundException(productName);
			
		}
		Product product=(Product)list.get(0);
		Stock stock= product.getStock();
		productVo.setId(product.getId());
		productVo.setProductType(stock.getProductType());
		productVo.setName(product.getName());
		productVo.setDesc(product.getDesc());
		productVo.setPrice(stock.getPrice());
		productVo.setUnit(stock.getUnit());
		return productVo;
		
	}
	public List<ProductVo> getAllProduct(){
		List<?> list=productCatalogueDao.getAllProduct();
		List<ProductVo> productList=convertIntoResponse(list);
		return productList;
	}
	private List<ProductVo> convertIntoResponse(List<?> list) {
		// TODO Auto-generated method stub
		List<ProductVo> listProduct= new ArrayList<ProductVo>();
		for(int i=0;i<list.size();i++){
			ProductVo productVo= new ProductVo();
			Product product= (Product) list.get(i);
		          
				Stock stock= product.getStock();
				productVo.setId(product.getId());
				productVo.setProductType(stock.getProductType());
				productVo.setName(product.getName());
				productVo.setDesc(product.getDesc());
				productVo.setPrice(stock.getPrice());
				productVo.setUnit(stock.getUnit());
			
			
			
			 
			listProduct.add(productVo);
		}
		return listProduct;
	}
	public void removeProduct(int productId){
		productCatalogueDao.removeProduct(productId);
	}
}
