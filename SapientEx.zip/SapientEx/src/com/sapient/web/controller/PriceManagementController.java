package com.sapient.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.sapient.web.constant.SapientConstants;
import com.sapient.web.model.ProductVo;


@RestController
public class PriceManagementController {

	@RequestMapping(value=SapientConstants.PRICESERVICE, method = RequestMethod.GET,produces={"application/json"})
	public ProductVo getProduct(@PathVariable("productname") String productName)  {
		System.out.println("price search Hit");
		 final String uri = "http://localhost:8081/SapientPractice/productcatelog/{productname}";
	     
		    Map<String, String> params = new HashMap<String, String>();
		    params.put("productname", productName);
		     
		    RestTemplate restTemplate = new RestTemplate();
		    ProductVo productVo = restTemplate.getForObject(uri, ProductVo.class, params);
		    System.out.println(productVo);
		return productVo;
		
		
	}
	
}
