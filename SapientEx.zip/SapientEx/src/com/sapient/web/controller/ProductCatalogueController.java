package com.sapient.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;


import com.sapient.web.constant.SapientConstants;
import com.sapient.web.model.ProductVo;
import com.sapient.web.service.ProductCatalogueService;
import com.sapient.web.util.ProductNotFoundException;



@RestController
public class ProductCatalogueController {
	
	@Autowired
	ProductCatalogueService productCatalogueService;
	
	@RequestMapping(value = SapientConstants.PRODUCTCATELOGADDSERVICE, method = RequestMethod.POST ,produces={"application/json"})
	public  void addProduct(@RequestBody ProductVo product) {
		System.out.println("product Add service Hit");
		productCatalogueService.addProduct(product);
		 
	}	
	@RequestMapping(value=SapientConstants.PRODUCTCATELOGLISTSERVICE, method = RequestMethod.GET,produces={"application/json"})
	public List<ProductVo> getAllProduct() {
		System.out.println("productList service Hit");
		List<ProductVo> productList=productCatalogueService.getAllProduct();
		return productList;
	}
	
	
	@RequestMapping(value=SapientConstants.PRODUCTCATELOGBYPRODUCTNAME, method = RequestMethod.GET,produces={"application/json"})
	public ProductVo getProduct(@PathVariable("productname") String productName) throws ProductNotFoundException {
		System.out.println("product service Hit");
	ProductVo product=productCatalogueService.getProduct(productName);
		return product;
	}
	
	@RequestMapping(value=SapientConstants.PRODUCTCATELOGREMOVESERVICE, method = RequestMethod.GET,produces={"application/json"})
	public int removeProduct(@PathVariable("productId") int pid) {
		System.out.println("product remove service Hit");
		productCatalogueService.removeProduct(pid);
		return pid;
		
		
	}

}
