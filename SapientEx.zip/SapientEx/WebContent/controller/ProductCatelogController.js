App.controller('ProductCatalogueController', function($scope,ProductCatelogService,ngDialog){
    var url='http://localhost:8081/SapientPractice/productcatelog/productlist';
    $scope.ProductList=[];
    $scope.productTypeList = ["ALL","Electronics", "Sports"];
	ProductCatelogService.productList(url).success(function(data){
		$scope.ProductList=data;
		$scope.dataAvailable=$scope.ProductList.length;
	});
	
	$scope.deleteB=function(productid){
		var url='http://localhost:8081/SapientPractice/productcatelog/remove/'+productid;
		ProductCatelogService.remove(url).success(function(data){
			$scope.deleteProduct(data);
		});
	};
	$scope.deleteProduct = function (id) {
        for (i in $scope.ProductList) {
            if ($scope.ProductList[i].id == id) {
            	$scope.ProductList.splice(i, 1);
            }
        }
        $scope.dataAvailable=$scope.ProductList.length;
    };
    
    $scope.addProduct=function(){
		ngDialog.open({		    		
    		template: 'view/addOverlay.html',
    		
    	
    	});
		
};	
});	
App.controller('addController', function($scope,ProductCatelogService,ngDialog,$route){
	$scope.productTypeList = ["Electronics", "Sports"];
	$scope.addProduct=function(){
		var dataObj={
				productType:$scope.productType,
				name:$scope.productname,
				desc:$scope.desc,
				price:$scope.price,
				unit:$scope.unit
				
				
		};
		
		 var url='http://localhost:8081/SapientPractice/productcatelog/add';
		ProductCatelogService.addProduct(url, dataObj).success(function(data,status){
			$route.reload('/productcat');	
		});
		ngDialog.closeAll();
		
				
	};
	
	
});


