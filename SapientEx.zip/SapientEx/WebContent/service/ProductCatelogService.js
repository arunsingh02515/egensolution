App.factory('ProductCatelogService', function ($http) {
    
	return {
		addProduct:function(myurl,obj){
			return $http.post(myurl,obj);
		},
		productList: function(myurl){
			return $http.get(myurl);
		},
		
		remove: function(myurl){
			return $http.get(myurl);
		},
		findProduct:function(myurl){
			return $http.get(myurl);
		},
	};
});