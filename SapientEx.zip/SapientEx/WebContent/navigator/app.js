var App = angular.module('sapient', ["ngRoute","ngDialog"]);
 
App.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/productcat', {
        templateUrl: 'view/ProductCatalogue.html',
        controller: 'ProductCatalogueController'
    }).
      when('/price', {
        templateUrl: 'view/price.html',
        controller: 'PriceController'
      }).
      otherwise({
        redirectTo: '/productcat'
      });
}]);
 
 

